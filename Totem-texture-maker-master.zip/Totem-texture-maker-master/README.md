# Totem-texture-maker
Grabs your skin and then creates a 1.12.2 totem texture!

I hade to remove the consel as the code was out dated and buggy




## INCSTRUCTIONS:

<details>
<summary>
  OFFLINE MODE:
</summary>


- clone the repository

- Move your skin into the folder called tot_build

- run the totskinmaker.exe

- then input the name of the skin file (it has to have .png on the end) - alternatively you can put the hole file dir

- then choose if your skin in slim or normal

- then check the folder where you put your skin in are there should be a new file called totem.png
</details>

<details>
<summary>
  ONLINE MODE:
</summary>

- To use the new API you will need to be connected to the internet 

- then click on ONLINE 

- then enter your username or UUID(UUID is preferred)

- then click go

- now if you look in the folder the .exe is in then you will see the totem texture!

</details>

<details>
<summary>
  ANIMATOR:
</summary>

- To use the animator you will need to select the number of frames in the animation

- you will then be asked to enter each img dir

- now if you look in the folder the .exe is in then you will see the totem texture!
</details>


![Alt text](https://i.ibb.co/gdm91n2/aaaaaa.png)

![Alt text](https://i.ibb.co/DfD55cc/ezgif-com-video-to-gif.gif)
